﻿// PhotoView
//Ignacio Montes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoView
{
    /// <summary>
    /// This class will hold the photos details
    /// </summary>
    public class Photograph
    {
        private String photoTitle;
        private DateTime photoDateTaken;
        private DateTime photoDateAdded;
        private String photoDescription;
        private String photoArtist;
        private String photoKeywords;
        private String photoLocation;

        /// <summary>
        /// Contructor to create the photograph list
        /// </summary>
        /// <param name="photoTitle">Title of the photo</param>
        /// <param name="photoDateTaken">Date the photo was taken</param>
        /// <param name="photoDateAdded">Date the photo was added to the viewer</param>
        /// <param name="photoDescription">Description of the photo</param>
        /// <param name="photoArtist">Person who took the photo</param>
        /// <param name="photoKeywords">Keywords use for a search</param>
        /// <param name="photoLocation">Location where the photo can be found</param>
        /// <returns>A photograph object with all pertinent data</returns>
        public Photograph(String photoTitle, DateTime photoDateTaken, String photoDescription, 
            String photoArtist, String photoKeywords, String photoLocation)
        {
            Title = photoTitle;
            Taken = photoDateTaken;
            Added = DateTime.Now;
            Description = photoDescription;
            Artist = photoArtist;
            Keywords = photoKeywords;
            PhotoLocation = photoLocation;
        }


        /// <summary>
        /// Properties used
        /// </summary>
        public String Title
        {
            get { return photoTitle; }
            set { photoTitle = value; }
        }

        public DateTime Taken
        {
            get { return photoDateTaken; }
            set { photoDateTaken = value; }
        }

        public String TakenString
        {
            // Used to display date only
            get { return photoDateTaken.ToShortDateString(); }
        }

        public DateTime Added
        {
            get { return photoDateAdded; }
            set { photoDateAdded = value; }
        }

        public String Description
        {
            get { return photoDescription; }
            set { photoDescription = value; }
        }

        public String Artist
        {
            get { return photoArtist; }
            set { photoArtist = value; }
        }

        public String Keywords
        {
            get { return photoKeywords; }
            set { photoKeywords = value; }
        }

        public String PhotoLocation
        {
            get { return photoLocation; }
            set { photoLocation = value; }
        }
    }
}
