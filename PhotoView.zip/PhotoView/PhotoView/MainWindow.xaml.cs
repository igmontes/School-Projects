﻿// PhotoView
//Ignacio Montes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PhotoView
{
    /// <summary>
    /// PhotoView class - Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PhotoList photoList = new PhotoList();
        DisplayList displayList = new DisplayList();
        public MainWindow()
        {
            InitializeComponent();

            // Build initial display list with full photographList contents
            foreach (Photograph ph in photoList)
            {
                displayList.AddToDisplay(ph.Title, ph.Taken, ph.Description, ph.Artist, ph.Keywords, ph.PhotoLocation);
            }
        }


        /// <summary>
        /// Calls method to refresh the displayList object.
        /// </summary>
        private void Photograph_Loaded(object sender, RoutedEventArgs e)
        {
            refreshBrowseList();
        }

        
        /// <summary>
        /// Used to display the corresponding photo and text boxes
        /// when a photograph in the displayList is selected.
        /// </summary>
        private void dataGrid_Photo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = dataGrid_Photo.SelectedIndex;
            if (index < 0)
                index = 0;
            Photograph ph = displayList[index];

            // Display corresponding photo
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(@ph.PhotoLocation);
            bitmap.EndInit();
            image_Photo.Stretch = Stretch.Uniform;
            image_Photo.Source = bitmap;

            // Populate textboxes
            textBox_title.Text = ph.Title.ToString();
            textBox_dateTaken.Text = ph.Taken.ToShortDateString();
            textBox_dateAdded.Text = ph.Added.ToShortDateString();
            textBox_description.Text = ph.Description.ToString();
            textBox_artistName.Text = ph.Artist.ToString();
            textBox_keyWords.Text = ph.Keywords.ToString();
        }

        
        /// <summary>
        /// Used to add a new photograph.  Launches dialog box to enter information.
        /// </summary>
        private void button_Upd_Click(object sender, RoutedEventArgs e)
        {
            EditPhoto editPh = new EditPhoto();
            bool action = (bool)editPh.ShowDialog();
            if (action == true)
            {
                // Add photograph to main list
                photoList.AddPhotograph(editPh.textBox_title.Text,
                    DateTime.Parse(editPh.textBox_dateTaken.Text), editPh.textBox_description.Text,
                    editPh.textBox_artistName.Text, editPh.textBox_keywords.Text,
                    editPh.textBox_fileLocation.Text);

                // Add photograph to display list
                displayList.AddToDisplay(editPh.textBox_title.Text,
                    DateTime.Parse(editPh.textBox_dateTaken.Text), editPh.textBox_description.Text,
                    editPh.textBox_artistName.Text, editPh.textBox_keywords.Text,
                    editPh.textBox_fileLocation.Text);
                // Update original photograph object
                refreshBrowseList();
            }
        }


        /// <summary>
        /// Refreshes displayList, set it to null and back to source,
        /// </summary>
        public void refreshBrowseList()
        {
            dataGrid_Photo.ItemsSource = null;
            dataGrid_Photo.ItemsSource = displayList;
            dataGrid_Photo.Columns[1].Visibility = Visibility.Collapsed;
            dataGrid_Photo.Columns[2].Header = "Date Taken";
            dataGrid_Photo.Columns[3].Visibility = Visibility.Collapsed;
            dataGrid_Photo.Columns[5].Visibility = Visibility.Collapsed;
            dataGrid_Photo.Columns[6].Visibility = Visibility.Collapsed;
            dataGrid_Photo.Columns[7].Visibility = Visibility.Collapsed;
            dataGrid_Photo.IsReadOnly = true;
        }


        /// <summary>
        /// Runs when clicking the Search button
        /// Clear the displayList, split (array) the keywords entered and
        /// look for the photo.
        /// </summary>
        private void button_GO_Click(object sender, RoutedEventArgs e)
        {
            displayList.Clear();
            String[] searchlist = textBox_Search.Text.Split(',');
            string resultsList = "";
            foreach (string s in searchlist)
            {
                // Change search entries to upper case
                string searchItem = s.ToUpper();
                searchItem = searchItem.Trim();  // Trim all spaces
                foreach (Photograph ph in photoList)
                {
                    if (ph.Title.ToUpper().Contains(searchItem) || ph.Artist.ToUpper().Contains(searchItem) ||
                        ph.Description.ToUpper().Contains(searchItem) || ph.Keywords.ToUpper().Contains(searchItem))
                    {
                        // Create results list (non-duplicate Titles)
                        if (!resultsList.Contains(ph.Title))
                        {
                            if (resultsList == "")
                            {
                                resultsList = ph.Title;
                            }
                            else
                            {
                                resultsList += "," + ph.Title;
                            }
                        }
                    }
                }
            }

            // Add photograph(s) to display list
            String[] results = resultsList.Split(',');
            foreach (string result in results)
            {
                foreach (Photograph ph in photoList)
                {
                    if (ph.Title.Contains(result))
                        displayList.AddToDisplay(ph.Title, ph.Taken, ph.Description, ph.Artist, ph.Keywords, ph.PhotoLocation);
                }
            }
            refreshBrowseList();
        }
    }
}