﻿// PhotoView
//Ignacio Montes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PhotoView
{
    public partial class EditPhoto : Window
    {
        /// <summary>
        /// Allow user to enter new photographs
        /// </summary>
        public EditPhoto()
        {
            InitializeComponent();
        }

        private void button_OK_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void button_Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }


        /// <summary>
        /// Method to select photograph from a folder
        /// </summary>
        private void button_Select_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = @"C:\Ignacio\FinalProject\Pics";
            ofd.Filter = "JPG (*.JPG)|*.JPG|JPEG (*.JPEG)|*.JPEG|All files (*.*)|*.*";
            if (ofd.ShowDialog() == true)
            {
                textBox_fileLocation.Text = ofd.FileName;
            }
        }
    }
}