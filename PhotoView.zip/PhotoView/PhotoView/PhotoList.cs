﻿// PhotoView
//Ignacio Montes

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PhotoView
{
    /// <summary>
    /// This class will contain the list of photographs
    /// </summary>
    public class PhotoList : List<Photograph>
    {
        /// <summary>
        /// Constructor to load the photos into the list
        /// </summary>
        public PhotoList()
        {
            string XMLFile = @"<Photos>"
                           + @"<Photo><Title>Accoustic</Title><Date>1/1/2014</Date><Description>accoustic semi-hollow bass</Description><Artist>Jane Doe</Artist><Keywords>accoustic, nylon strings, semi, hollow, semi-hollow</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\700-ac40.jpg</FileLocation></Photo>"
                           + @"<Photo><Title>Bromberg</Title><Date>1/3/2014</Date><Description>Brian Bromberg signature flamed maple bass</Description><Artist>Brian Bromberg</Artist><Keywords>neck, through, neck-through, signature, Brian, Bromberg, flamed, maple</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\700-b24.jpg</FileLocation></Photo>"
                           + @"<Photo><Title>Vader</Title><Date>1/8/2014</Date><Description>Vader neck-through headless bass</Description><Artist>Ignacio Montes</Artist><Keywords>vader, neck, through, neck-through, headless</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\700-vb4.jpg</FileLocation></Photo>"
                           + @"<Photo><Title>Jazz</Title><Date>1/12/2014</Date><Description>Classic jazz bolt-on neck bass</Description><Artist>Emma Montes</Artist><Keywords>classic, jazz, bolt, bolt-on</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\700-jb4.jpg</FileLocation></Photo>"
                           + @"<Photo><Title>Classic</Title><Date>1/12/2014</Date><Description>Classic bolt-on neck bass</Description><Artist>Ethan Montes</Artist><Keywords>classic, bolt, bolt-on</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\700-pb4.jpg</FileLocation></Photo>"
                           + @"<Photo><Title>BX700</Title><Date>1/16/2014</Date><Description>Mono block 700W bass amp head</Description><Artist>John Carter</Artist><Keywords>700W, amp, bass head, power, amplifier</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\BX700-5.jpeg</FileLocation></Photo>"
                           + @"<Photo><Title>BX1500</Title><Date>1/20/2014</Date><Description>Lightweight 1500W bass amp head</Description><Artist>Shawn Smith</Artist><Keywords>1500W, amp, bass head, power, amplifier</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\BX1500.jpeg</FileLocation></Photo>"
                           + @"<Photo><Title>BR410</Title><Date>1/25/2014</Date><Description>4X10 inch 800W 4ohm bass cabinet</Description><Artist>Shawn Michaels</Artist><Keywords>cab, bass cabinet, cabinet, speaker, bass speaker</Keywords><FileLocation>C:\Ignacio\FinalProject\Pics\4X10.JPG</FileLocation></Photo>"
                           + @"</Photos>";

            Regex XMLPattern = new Regex(@"^(\<Photos\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<Photo\>)(.*)(\<\/Photo\>)(\<\/Photos\>)$");
            Match XMLMatch = XMLPattern.Match(XMLFile);

            int i = 0;
            while (i < 24)
            {
                i += 3;
                Regex PhotoPattern = new Regex(@"^(\<Title\>)(.*)(\<\/Title\>)(\<Date\>)(.*)(\<\/Date\>)(\<Description\>)(.*)(\<\/Description\>)(\<Artist\>)(.*)(\<\/Artist\>)(\<Keywords\>)(.*)(\<\/Keywords\>)(\<FileLocation\>)(.*)(\<\/FileLocation\>)");

                Match TitleMatch = PhotoPattern.Match(XMLMatch.Groups[i].ToString());
                Match DateMatch = PhotoPattern.Match(XMLMatch.Groups[i].ToString());
                Match DescriptionMatch = PhotoPattern.Match(XMLMatch.Groups[i].ToString());
                Match ArtistMatch = PhotoPattern.Match(XMLMatch.Groups[i].ToString());
                Match KeywordsMatch = PhotoPattern.Match(XMLMatch.Groups[i].ToString());
                Match FileLocationMatch = PhotoPattern.Match(XMLMatch.Groups[i].ToString());

                // Add photograph to list
                Add(new Photograph(TitleMatch.Groups[2].ToString(), DateTime.Parse(DateMatch.Groups[5].ToString()),
                    DescriptionMatch.Groups[8].ToString(), ArtistMatch.Groups[11].ToString(),
                    KeywordsMatch.Groups[14].ToString(), FileLocationMatch.Groups[17].ToString()));
            }
        }

        /// <summary>
        /// Method used to add photos to the photoList object, this is 1 of 2 lists we are using and
        /// both lists are being populated in the same manner
        /// <param name="title">Photograph title</param>
        /// <param name="dateTaken">Date Photograph was taken</param>
        /// <param name="description">Photograph description</param>
        /// <param name="artistName">Photograph artist name</param>
        /// <param name="keywords">Photograph keywords</param>
        /// <param name="fileLocation">Photograph file location</param>
        /// </summary>
        public void AddPhotograph(string title, DateTime dateTaken, string description, string artistName,
            string keywords, string fileLocation)
        {
            Add(new Photograph(title, dateTaken, description, artistName, keywords, fileLocation));
        }
    }

    /// <summary>
    /// DisplayList class used add photographs to the displayList, this is the 2nd list we are using
    /// </summary>
    /// <param name="title">Photograph title</param>
    /// <param name="dateTaken">Date Photograph was taken</param>
    /// <param name="description">Photograph description</param>
    /// <param name="artistName">Photograph artist name</param>
    /// <param name="keywords">Photograph keywords</param>
    /// <param name="fileLocation">Photograph file location</param>
    /// <returns>Photograph object</returns>
    public class DisplayList : List<Photograph>
    {
        public void AddToDisplay(string title, DateTime dateTaken, string description, string artistName,
        string keywords, string fileLocation)
        {
            Add(new Photograph(title, dateTaken, description, artistName, keywords, fileLocation));
        }
    }
}