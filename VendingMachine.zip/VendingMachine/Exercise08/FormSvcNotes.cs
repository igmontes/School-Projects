﻿// Exercise 08
// Author: Montes, Jorge

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Exercise08
{
    public partial class FormSvcNotes : Form
    {
        public FormSvcNotes()
        {
            InitializeComponent();
        }

        private void newNoteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form formSvcNote = new FormSvcNote();
            formSvcNote.MdiParent = this;
            formSvcNote.Show();
        }

        private void createServiceNote()
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // First we make sure there is an active service note
            if (this.ActiveMdiChild == null)
            {
                MessageBox.Show("No Service Notes available.");
            }
            else
            {
                // Save service note contents
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.FileName = "NewServiceNote.txt";
                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    StreamWriter sw;
                    using (sw = new StreamWriter(saveFileDialog.FileName))
                    {
                        sw.Write((this.ActiveMdiChild as FormSvcNote).textBoxSvcNoteText);
                    }
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                createServiceNote();
                Form formSvcNote = new FormSvcNote();
                formSvcNote.MdiParent = this;
                formSvcNote.Show();
                (this.ActiveMdiChild as FormSvcNote).textBoxSvcNoteText = "Hello";

                StreamReader sr;
                using (sr = new StreamReader(openFileDialog.FileName))
                {
                    (this.ActiveMdiChild as FormSvcNote).textBoxSvcNoteText = sr.ReadToEnd();
                }

            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
