﻿// Exercise 08
// Author: Montes, Jorge

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using _06._0_Console_As_Library;


namespace Exercise08
{
    public partial class FormVendMachine : Form
    {
        public FormVendMachine()
        {
            InitializeComponent();

            // Subscribe to tab changed event.  I had to do this since the tab control's event handler
            // only worked when clicking on the selected tab's page, not the tab itself.
            tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;
        }

        // Create vending machine coin box
        private CoinBox vendMachineCoinBox = new CoinBox(new List<Coin> {
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME),
                new Coin(Coin.Denomination.NICKEL), new Coin(Coin.Denomination.QUARTER),
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME) });

        // Create can purchase transaction coin box
        private CoinBox transCoinBox = new CoinBox();

        // Set the price
        private PurchasePrice sodaPrice = new PurchasePrice(0.35M);

        // Create the can rack
        CanRack rack = new CanRack();

        // When form loads, set the price label dynamically
        private void FormVendMachine_Load(object sender, EventArgs e)
        {
            label1.Text = string.Format("Please insert {0} cents for a can of soda", sodaPrice.Price);

            // Exact change required label is visible if we can't make change
            labelExactChange.Visible = !vendMachineCoinBox.CanMakeChange;
        }

        // Enter Half Dollar
        private void btn_HalfDollar_Click(object sender, EventArgs e)
        {
            Coin halfDollar = new Coin(Coin.Denomination.HALFDOLLAR);
            insertCoinInTransBox(halfDollar);
        }

        // Deposit coin, Update transaction box amount, and enable/disable soda dispense buttons
        private void insertCoinInTransBox(Coin ACoin)
        {
            transCoinBox.Deposit(ACoin);
            updTotalAmountEntered();
            dispenseButtonsEnable();
        }

        // Update Amount Entered label, Enable Coin Return button
        private void updTotalAmountEntered()
        {
            labelAmtEntered.Text = string.Format("Amount Entered: {0:C}", transCoinBox.ValueOf);
            btn_CoinReturn.Enabled = transCoinBox.ValueOf > 0M;
        }

        // If enough money entered to buy a soda, then enable dispense buttons
        private void dispenseButtonsEnable()
        {
            if (transCoinBox.ValueOf >= sodaPrice.PriceDecimal)
            {
                btn_Regular.Enabled = !rack.IsEmpty(Flavor.REGULAR);
                btn_Orange.Enabled = !rack.IsEmpty(Flavor.ORANGE);
                btn_Lemon.Enabled = !rack.IsEmpty(Flavor.LEMON);
            }
            else
            {
                btn_Regular.Enabled = false;
                btn_Orange.Enabled = false;
                btn_Lemon.Enabled = false;
            }

        }

        private void btn_Quarter_Click(object sender, EventArgs e)
        {
            Coin quarter = new Coin(Coin.Denomination.QUARTER);
            insertCoinInTransBox(quarter);
        }

        private void btn_Dime_Click(object sender, EventArgs e)
        {
            Coin dime = new Coin(Coin.Denomination.DIME);
            insertCoinInTransBox(dime);
        }

        private void btn_Nickel_Click(object sender, EventArgs e)
        {
            Coin nickel = new Coin(Coin.Denomination.NICKEL);
            insertCoinInTransBox(nickel);
        }

        private void btn_Regular_Click(object sender, EventArgs e)
        {
            dispenseSoda(Flavor.REGULAR);
        }

        private void btn_Orange_Click(object sender, EventArgs e)
        {
            dispenseSoda(Flavor.ORANGE);
        }

        private void btn_Lemon_Click(object sender, EventArgs e)
        {
            dispenseSoda(Flavor.LEMON);
        }

        // Dispense can of soda
        private void dispenseSoda(Flavor AFlavor)
        {
            decimal amountEntered = transCoinBox.ValueOf;

            // If enough money to buy a soda is entered, and rack is not empty, dispense soda
            if (transCoinBox.ValueOf >= sodaPrice.PriceDecimal && !rack.IsEmpty(AFlavor))
            {
                transCoinBox.Transfer(vendMachineCoinBox);      // Move money from transaction box to vending machine coin box
                updTotalAmountEntered();                        // Empty out Amount Entered label, and disable Coin Return button
                rack.RemoveACanOf(AFlavor);                     // Remove a can of soda
                MessageBox.Show(string.Format("Thanks. Here is your {0} soda.", AFlavor.ToString()));
                dispenseButtonsEnable();                        // Enable/disable soda dispense buttons

                // Calc and dispense change, if vending machine coin box can make change
                decimal changeDue = amountEntered - sodaPrice.PriceDecimal;
                if (changeDue > 0M && vendMachineCoinBox.CanMakeChange)
                {
                    vendMachineCoinBox.Withdraw(changeDue);
                    MessageBox.Show(string.Format("Here is your {0:c} in change.", changeDue));
                }
                // Display Exact Change label if not enough money to make change
                labelExactChange.Visible = !vendMachineCoinBox.CanMakeChange;
            }
        }

        private void btn_CoinReturn_Click(object sender, EventArgs e)
        {
            // If any money in the transaction coin box, return it and zero out the transaction box
            if (transCoinBox.ValueOf > 0M)
            {
                MessageBox.Show(string.Format("Here is your refund of {0:c}.", transCoinBox.ValueOf));
                transCoinBox.Withdraw(transCoinBox.ValueOf);
                updTotalAmountEntered();
            }

            // Disable soda dispense buttons
            dispenseButtonsEnable();
        }

        // Tab control event handler
        private void tabControl1_SelectedIndexChanged(Object sender, EventArgs e)
        {

            // if Vending machine tab, refresh items that could be affected by Service tab changes, and vice versa
            if (tabControl1.SelectedIndex == 0)
            {
                tabVendSelected();
            }
            else
            {
                tabServiceSelected();
            }

        }

        // VEND TAB
        private void tabVendSelected()
        {
            // Disable soda dispense buttons
            dispenseButtonsEnable();

            // Exact change required label is visible if we can't make change
            labelExactChange.Visible = !vendMachineCoinBox.CanMakeChange;

            // Update Amount Entered label, Enable Coin Return button
            updTotalAmountEntered();
        }

        // SERVICE TAB
        private void tabServiceSelected()
        {
            // Populate all 3 listviews
            RefreshCanRackList();
            RefreshCoinBox(vendMachineCoinBox, listViewVMCoinBox);
            RefreshCoinBox(transCoinBox, listViewTransBox);
        }

        private void tabService_Click(object sender, EventArgs e)
        {
        }

        // SERVICE TAB - Refill Can Rack
        private void btn_RefillRack_Click(object sender, EventArgs e)
        {
            // Refill the racks
            rack.FillTheCanRack();

            // Refresh listview
            RefreshCanRackList();
        }

        // SERVICE TAB - Refresh Can Rack List
        private void RefreshCanRackList()
        {
            // First, clear list
            listViewCanRack.Items.Clear();

            // Second, we can populate listview
            foreach (Flavor eachFlavor in FlavorOps.AllFlavors)
            {
                ListViewItem canRackRow = new ListViewItem(eachFlavor.ToString());
                canRackRow.SubItems.Add(rack[eachFlavor].ToString());
                listViewCanRack.Items.Add(canRackRow);
            }
        }

        // SERVICE TAB - Refresh coin box (used for all coin boxes)
        private void RefreshCoinBox(CoinBox coinBox, ListView listView)
        {
            // First, clear list
            listView.Items.Clear();

            // Second, we can populate listview
            List<Coin.Denomination> listOfCoins = new List<Coin.Denomination>(Coin.AllDenominations);

            foreach (Coin.Denomination eachCoin in listOfCoins)
            {
                // No slugs
                if (eachCoin.ToString() == "SLUG") continue;

                ListViewItem vmCoinRow = new ListViewItem(eachCoin.ToString());
                int numberOfCoins = coinBox.coinCount(eachCoin);
                decimal totalCoinValue = numberOfCoins * Coin.ValueOfCoin(eachCoin);
                vmCoinRow.SubItems.Add(numberOfCoins.ToString());
                vmCoinRow.SubItems.Add(string.Format("{0:c}", totalCoinValue));
                listView.Items.Add(vmCoinRow);
            }

        }

        // SERVICE TAB - Empty coin box (used for all coin boxes)
        private void EmptyCoinBox(CoinBox coinBox, ListView listView)
        {
            // First, we remove all coins
            List<Coin.Denomination> listOfCoins = new List<Coin.Denomination>(Coin.AllDenominations);

            foreach (Coin.Denomination eachCoin in listOfCoins)
            {
                // No slugs
                if (eachCoin.ToString() == "SLUG") continue;

                int numberOfCoins = coinBox.coinCount(eachCoin);
                for (int i = 0; i < numberOfCoins; i++)
                {
                    coinBox.Withdraw(eachCoin);
                }
            }
            // Then we can refresh the listview
            RefreshCoinBox(coinBox, listView);
        }

        // SERVICE TAB - Empty Vending Machine Coin Box
        private void btn_EmptyVMBox_Click(object sender, EventArgs e)
        {
            // Call method to empty coin box, sending which coin box and listview to process
            EmptyCoinBox(vendMachineCoinBox, listViewVMCoinBox);
        }

        // SERVICE TAB - Empty Transaction Coin Box
        private void btn_EmptyTransBox_Click(object sender, EventArgs e)
        {
            // Call method to empty coin box, sending which coin box and listview to process
            EmptyCoinBox(transCoinBox, listViewTransBox);
        }

        private void tabVend_Click(object sender, EventArgs e)
        {
        }

        Form fSvcNotes = null;
        private void btn_SvcNotes_Click(object sender, EventArgs e)
        {
            if (fSvcNotes == null)
            {
                fSvcNotes = new FormSvcNotes();
                fSvcNotes.Show();
            }
            else
            {
                fSvcNotes.Focus();
            }
        }
    }
}