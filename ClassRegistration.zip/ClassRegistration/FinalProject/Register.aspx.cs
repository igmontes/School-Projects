﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class Register : System.Web.UI.Page
    {
        //Define output parameters
        public System.Data.DataSet dataset;
        public string success, error, statError;
        LogInClass resultSession;

        protected void Page_Load(object sender, EventArgs e)
        {
            //Check if user is logged in, send to login screen if needed
            if (Session["LoggedIn"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                resultSession = (LogInClass)Session["LoggedIn"];
            }


            //Connect to database and get the classes for the initial populating of the grid view
            if (!this.IsPostBack)
            {
                //Call class to process database request
                RegisterClass RegisterClass = new RegisterClass(out dataset);

                //Check if we have data
                if (dataset == null)
                {
                    Label1.Text = "WARNING, an unexpected error has occured while retrieving the classes, we will look into this for you.";
                }
                else
                {
                    //Populate the gridview
                    GridView1.DataSource = dataset;
                    GridView1.DataBind();
                }
            }
        }


        //Clicking the "Register" button
        protected void Button1_Click(object sender, EventArgs e)
        {
            //going through the list to see if at least one course has been selected
            int numberOfRecords = 0;
            foreach (GridViewRow row in GridView1.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                    if (chkRow.Checked)
                    {
                        numberOfRecords = 1;
                    }
                }
            }


            //At lease one course was selected
            if (numberOfRecords == 1)
            {
                //Create the connection object
                OleDbConnection oleCon = new OleDbConnection();
                oleCon.ConnectionString = WebConfigurationManager.ConnectionStrings["Finaldb"].ConnectionString;

                //Try to submit to the database
                try
                {
                    using (oleCon)
                    {
                        oleCon.Open();

                        //Gather all the selected courses
                        foreach (GridViewRow row in GridView1.Rows)
                        {
                            CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                            if (chkRow.Checked)
                            {
                                //Call class to process database request
                                RegisterButton RegisterButton = new RegisterButton(Convert.ToInt32(row.Cells[1].Text), Convert.ToInt32(resultSession.sessionStudentID.ToString()), oleCon, out success, out statError);
                            }
                        }

                        //Check for a successful database submission
                        if (success == "NO")
                        {
                            Label1.Text = "There was an error while processing your request, we will look into it";
                        }
                        else if (success == "Yes")
                        {
                            Response.Redirect("MyClasses.aspx");
                        }
                        else if (statError.Contains("Violation of PRIMARY KEY") == true)
                        {
                            Label1.Text = "NOTE - You are already registered to at least one of the selected classes. Go to 'My Classes' to review.";
                        }
                        oleCon.Close();
                    }
                }
                catch (Exception err)
                {
                    Label1.Text = "There was an error while processing your request, we will look into it";
                    error = err.Message;
                }
            }
            else  //No courses selected
            {
                Label1.Text = "NOTE - Please select a class to register to"; 
            }
        }
    }
}
