﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class MyClasses : System.Web.UI.Page
    {
        //Define output parameters
        public System.Data.DataSet dataset;
        private LogInClass resultSession;
        public string success;
        int sessID;

        //Test
        string testResult;

        protected void Page_Load(object sender, EventArgs e)
        {
            //Check if user is logged in, send to login screen if needed
            if (Session["LoggedIn"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                resultSession = (LogInClass)Session["LoggedIn"];
            }


            //Connect to database get the classes for the initial populating of the grid view
            if (!this.IsPostBack)
            {
                //Define parameters
                sessID = Convert.ToInt32(resultSession.sessionStudentID.ToString());

                //Call class to process database request
                MyRegisteredClasses MyRegisteredClasses = new MyRegisteredClasses(sessID, out dataset, out testResult);

                //Check to see if we have data
                if (dataset == null)
                {
                    Label1.Text = "WARNING, an unexpected error has occured while retrieving the classes, we will look into this for you.";
                }
                else
                {
                    //Populate the gridview
                    GridView1.DataSource = dataset;
                    GridView1.DataBind();
                }

                //If not registered to any classes yet
                if (testResult == "False")
                {
                    Label1.Text = "Note - You are not registered in any classes yet, please register in at least one class.";
                }
            }
        }
    }
}
