﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;

namespace FinalProject.App_Code
{
    public partial class LogInClass : System.Web.UI.Page
    {
        //Defining fields
        public string userName, passWord, error;
        public int sessionStudentID;
        public int result;

        //Running the connection and database request
        public LogInClass(string UserName, string PassWord, out int SessionStudentId)
        {
            //Populating the fields
            this.userName = UserName;
            this.passWord = PassWord;

            //Create the connection object
            OleDbConnection oleCon = new OleDbConnection();
            oleCon.ConnectionString = WebConfigurationManager.ConnectionStrings["Finaldb"].ConnectionString;

            //Create the command object
            OleDbCommand oleCmd = new OleDbCommand("pSelLoginIdByLoginAndPassword", oleCon);
            oleCmd.CommandType = System.Data.CommandType.StoredProcedure;

            //Create the parameters
            OleDbParameter oleUser = new OleDbParameter("@StudentLogin", OleDbType.VarChar);
            oleUser.Direction = System.Data.ParameterDirection.Input;
            oleUser.Value = userName;
            oleCmd.Parameters.Add(oleUser);

            OleDbParameter olePass = new OleDbParameter("@StudentPassword", OleDbType.VarChar);
            olePass.Direction = System.Data.ParameterDirection.Input;
            olePass.Value = passWord;
            oleCmd.Parameters.Add(olePass);

            OleDbParameter oleID = new OleDbParameter("@StudentId", OleDbType.Integer);
            oleID.Direction = System.Data.ParameterDirection.Output;
            oleCmd.Parameters.Add(oleID);

            //Loging in and returning the student ID
            try
            {
                using (oleCon)
                {
                    oleCon.Open();
                    oleCmd.ExecuteScalar();
                    oleCon.Close();
                    result = Convert.ToInt32(oleID.Value);
                }
            }
            catch (Exception err)
            {
                result = 0;
                error = err.Message;
            }

            //Return the student ID
            SessionStudentId = result;
            this.sessionStudentID = SessionStudentId;
        }
    }
}