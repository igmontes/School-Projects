﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;

namespace FinalProject.App_Code
{
    public class RegisterButton : System.Web.UI.Page
    {
        //Define fields
        public int classID, studentID;
        OleDbConnection dbcon;
        public string success, errors;

        //Run database request
        public RegisterButton(int ClassID, int StudentID, OleDbConnection DBCon, out string Success, out string Errors)
        {
            //Set the parameters
            classID = ClassID;
            studentID = StudentID;
            dbcon = DBCon;

            try
            {
                //Create the command object
                OleDbCommand oleCmd = new OleDbCommand("pInsClassStudents", DBCon);
                oleCmd.CommandType = System.Data.CommandType.StoredProcedure;

                //Create All input parameters
                OleDbParameter oleClass = new OleDbParameter("@ClassId", OleDbType.Integer);
                oleClass.Direction = System.Data.ParameterDirection.Input;
                oleClass.Value = classID;
                oleCmd.Parameters.Add(oleClass);

                OleDbParameter oleStudent = new OleDbParameter("@StudentId", OleDbType.Integer);
                oleStudent.Direction = System.Data.ParameterDirection.Input;
                oleStudent.Value = studentID;
                oleCmd.Parameters.Add(oleStudent);

                //Run the query
                oleCmd.ExecuteNonQuery();

                Success = "Yes";
                Errors = "";
            }
            catch (Exception err)
            {
                Success = "No";
                Errors = err.Message;
            }

            //return result
            success = Success;
            errors = Errors;
        }
    }
}