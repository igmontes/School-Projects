﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;

namespace FinalProject.App_Code
{
    public partial class MyRegisteredClasses : System.Web.UI.Page
    {
        //Define fields
        public string result, test, testReturn;
        public int studentID;
        public System.Data.DataSet data;

        //Running connection and populating the dataset
        public MyRegisteredClasses(int StudentID, out System.Data.DataSet Data, out string TestReturn)
        {
            //Set parameters
            studentID = StudentID;

            //Create the connection object
            OleDbConnection oleCon = new OleDbConnection();
            oleCon.ConnectionString = WebConfigurationManager.ConnectionStrings["Finaldb"].ConnectionString;

            //Create the command object
            OleDbCommand oleCmd = new OleDbCommand("pSelClassesByStudentID", oleCon);
            oleCmd.CommandType = System.Data.CommandType.StoredProcedure;

            //Create the parameters
            OleDbParameter oleUser = new OleDbParameter("@StudentID", OleDbType.Integer);
            oleUser.Direction = System.Data.ParameterDirection.Input;
            oleUser.Value = studentID;
            oleCmd.Parameters.Add(oleUser);

            //Create Adapter object
            OleDbDataAdapter oleAdapter = new OleDbDataAdapter(oleCmd);

            //Create dataset object
            System.Data.DataSet dataset = new System.Data.DataSet();


            //Try to connect to database and get the data
            try
            {
                using (oleCon)
                {
                    oleCon.Open();
                    oleAdapter.Fill(dataset);
                    oleCon.Close();

                    //Test
                    System.Data.DataTableReader reader = dataset.CreateDataReader();
                    test = reader.HasRows.ToString();
                        
                }
            }
            catch (Exception err)
            {
                result = err.Message.ToString();
            }

            //Return the data
            Data = dataset;
            data = Data;
            TestReturn = test;
            testReturn = TestReturn;
        }
    }
}