﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;

namespace FinalProject.App_Code
{
    public partial class RegisterClass : System.Web.UI.Page
    {
        //Define fields
        public string result, error;
        public System.Data.DataSet data;

        //Running connection and populating the dataset
        public RegisterClass(out System.Data.DataSet Data)
        {
            //Create the connection object
            OleDbConnection oleCon = new OleDbConnection();
            oleCon.ConnectionString = WebConfigurationManager.ConnectionStrings["Finaldb"].ConnectionString;

            //Create the command object
            OleDbCommand oleCmd = new OleDbCommand("SELECT ClassID, ClassName, ClassDate, ClassDescription FROM vClasses", oleCon);
            oleCmd.CommandType = System.Data.CommandType.Text;

            //Create Adapter object
            OleDbDataAdapter oleAdapter = new OleDbDataAdapter(oleCmd);

            //Create dataset object
            System.Data.DataSet dataset = new System.Data.DataSet();


            //Try to connect to database and pull the data
            try
            {
                //Populate the grid view
                using (oleCon)
                {
                    oleCon.Open();
                    oleAdapter.Fill(dataset);
                    oleCon.Close();
                }
            }
            catch (Exception err)
            {
                error = err.Message;
            }

            //Return the dataset
            Data = dataset;
            data = Data;
        }
    }
}