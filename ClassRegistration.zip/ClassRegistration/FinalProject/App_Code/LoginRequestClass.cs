﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;


namespace FinalProject.App_Code
{
    public partial class LoginRequestClass : System.Web.UI.Page
    {
        //Define fields
        public string name, email, loginName, loginType, reasonForAccess, loginCreated, error;
        public DateTime dateNeeded;

        //Running the connection and submitting to the database
        public LoginRequestClass(string Name, string Email, string LoginName, string LoginType, string ReasonForAccess, DateTime DateNeeded, out string LoginCreated )
        {
            this.name = Name;
            this.email = Email;
            this.loginName = LoginName;
            this.loginType = LoginType;
            this.reasonForAccess = ReasonForAccess;
            this.dateNeeded = DateNeeded;

            //Create the connection object
            OleDbConnection oleCon = new OleDbConnection();
            oleCon.ConnectionString = WebConfigurationManager.ConnectionStrings["Finaldb"].ConnectionString;

            //Create the command object
            OleDbCommand oleCmd = new OleDbCommand("pInsLoginRequest", oleCon);
            oleCmd.CommandType = System.Data.CommandType.StoredProcedure;

            //Create All input parameters
            OleDbParameter oleName = new OleDbParameter("@Name", OleDbType.VarWChar);
            oleName.Direction = System.Data.ParameterDirection.Input;
            oleName.Value = name;
            oleCmd.Parameters.Add(oleName);

            OleDbParameter oleEmail = new OleDbParameter("@EmailAddress", OleDbType.VarWChar);
            oleEmail.Direction = System.Data.ParameterDirection.Input;
            oleEmail.Value = email;
            oleCmd.Parameters.Add(oleEmail);

            OleDbParameter oleLogin = new OleDbParameter("@LoginName", OleDbType.VarWChar);
            oleLogin.Direction = System.Data.ParameterDirection.Input;
            oleLogin.Value = loginName;
            oleCmd.Parameters.Add(oleLogin);

            OleDbParameter oleNew = new OleDbParameter("@NewOrReactivate", OleDbType.VarWChar);
            oleNew.Direction = System.Data.ParameterDirection.Input;
            oleNew.Value = loginType;
            oleCmd.Parameters.Add(oleNew);

            OleDbParameter oleReason = new OleDbParameter("@ReasonForAccess", OleDbType.VarWChar);
            oleReason.Direction = System.Data.ParameterDirection.Input;
            oleReason.Value = reasonForAccess;
            oleCmd.Parameters.Add(oleReason);

            OleDbParameter oleDate = new OleDbParameter("@DateNeededBy", OleDbType.Date);
            oleDate.Direction = System.Data.ParameterDirection.Input;
            oleDate.Value = dateNeeded;
            oleCmd.Parameters.Add(oleDate);


            //Try submitting to the database
            try
            {
                using (oleCon)
                {
                    oleCon.Open();
                    oleCmd.ExecuteNonQuery();
                    oleCon.Close();

                    LoginCreated = "success";
                }

            }
            catch (Exception err)
            {
                LoginCreated = "error";
                error = err.Message;
            }

            //Return result of submission
            this.loginCreated = LoginCreated;
        }
    }
}