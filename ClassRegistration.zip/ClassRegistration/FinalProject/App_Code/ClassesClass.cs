﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;

namespace FinalProject.App_Code
{
    public partial class ClassesClass : System.Web.UI.Page
    {
        //Defining fields
        public string result;
        public System.Data.DataSet data;

        //running connection and populating the dataset
        public ClassesClass(out System.Data.DataSet Data)
        {
            //Create the connection object
            OleDbConnection oleCon = new OleDbConnection();
            oleCon.ConnectionString = WebConfigurationManager.ConnectionStrings["Finaldb"].ConnectionString;

            //Create the command object
            OleDbCommand oleCmd = new OleDbCommand("SELECT ClassID, ClassName, ClassDate, ClassDescription FROM vClasses", oleCon);
            oleCmd.CommandType = System.Data.CommandType.Text;

            //Create Adapter object
            OleDbDataAdapter oleAdapter = new OleDbDataAdapter(oleCmd);

            //Create dataset object
            System.Data.DataSet dataset = new System.Data.DataSet();


            //Try to connect and get the data
            try
            {
                using (oleCon)
                {
                    oleCon.Open();
                    oleAdapter.Fill(dataset);
                    oleCon.Close();
                }
            }
            catch (Exception err)
            {
                result = err.Message.ToString();
            }

            // Return the dataset
            Data = dataset;
            data = Data;
        }
    }
}