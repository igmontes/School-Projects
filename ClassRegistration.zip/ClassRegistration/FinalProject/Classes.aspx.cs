﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Web.Configuration;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class Classes : System.Web.UI.Page
    {
        //Define output parameters
        public System.Data.DataSet dataset;

        protected void Page_Load(object sender, EventArgs e)
        {
            //Load only the first time the screen is rendered
            if (!this.IsPostBack)
            {
                //Call class to process database request
                ClassesClass ClassesClass = new ClassesClass(out dataset);

                //Make sure we have data in the dataset
                if (dataset == null)
                {
                    Label1.Text = "WARNING, an unexpected error has occured while retrieving the classes, we will look into this for you.";
                }
                else
                {
                    //Bind the data to the gridview
                    GridView1.DataSource = dataset;
                    GridView1.DataBind();
                }
            }
        }

    }
}
