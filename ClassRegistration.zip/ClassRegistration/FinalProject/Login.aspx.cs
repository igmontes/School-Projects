﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.OleDb;
using System.Web.Configuration;
using System.Web.UI.WebControls;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        //Login button is clicked
        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            //Define output parameters
            int oleID;

            //Call class to process database requests
            LogInClass loginClass = new LogInClass(Login1.UserName, Login1.Password, out oleID);

            //Checking for a succesful login by checking if we have a student ID number
            if (oleID <= 0)
            {
                Login1.FailureText = "Username and/or password is incorrect.";
            }
            else
            {
                Session["LoggedIn"] = loginClass;
                LogInClass resultSession = (LogInClass)Session["LoggedIn"];

                Login1.FailureText = " ";
                Login1.UserName = " ";

                //Redirect to the greeting
                Response.Redirect("Greeting.aspx");
            }
        }
    }
}