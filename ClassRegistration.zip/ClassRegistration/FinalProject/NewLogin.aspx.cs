﻿//Course:     Creating Web Applications in C#
//Assignment: Final Project
//Student:    Ignacio Montes Romo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.OleDb;
using FinalProject.App_Code;

namespace FinalProject
{
    public partial class NewLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //When the submit button is clicked
        public void Button1_Click(object sender, EventArgs e)
        {
            //Define output parameters
            string status;

            //Call class to process database request
            LoginRequestClass LoginRequestClass = 
                new LoginRequestClass(name.Text, email.Text, login.Text, ddlNew.Text, reason.Text, Convert.ToDateTime(DateBy.Text), out status );

            //Checking for a succesful submissionto the database
            if (status == "success")
            {
                //Reset the controls and display appropriate message on the screen
                name.Text = "";
                email.Text = "";
                login.Text = "";
                DateBy.Text = "";
                ddlNew.Text = "New";
                reason.Text = "";
                FooterText.Text = "NOTE: Thank you for your request, we will send you a password once it has been processed.";
            }
            else
            {
                FooterText.Text = " WARNING, an unexpected error has occured when submiting your request, we will look into this for you.";
            }
        }
    }
}