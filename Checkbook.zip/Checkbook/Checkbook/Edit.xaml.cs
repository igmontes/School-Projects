﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Checkbook
{
    /// <summary>
    /// Interaction logic for Edit.xaml
    /// </summary>
    public partial class Edit : Window
    {
        Transaction transaction;
        public Edit(Transaction transaction, CategoryList categories)
        {
            InitializeComponent();
            this.transaction = transaction;
            ShowTransaction(this.transaction);
            foreach (Category item in categories)
            {
                cbCategory.Items.Add(item.Title);
            }
        }
        private void ShowTransaction(Transaction transaction)
        {
            this.txtId.Text = transaction.Id.ToString();
            this.txtType.Text = transaction.Type.ToString();
            this.txtDescription.Text = transaction.Description.ToString();
            this.txtStringAmount.Text = transaction.AmountString.ToString();
            this.txtCheckNum.Text = transaction.Checknum.ToString();
            this.txtDate.Text = transaction.Date.ToShortDateString();
            this.txtAmount.Text = transaction.Amount.ToString("#.00");
            this.cbCategory.SelectedItem = transaction.Category; 
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }
        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            this.transaction.Date = DateTime.Parse(txtDate.Text);
            this.transaction.Description = txtDescription.Text;
            this.transaction.Category = cbCategory.Text;
            this.transaction.Amount = Decimal.Parse(txtAmount.Text);
            this.transaction.Checknum = txtCheckNum.Text;
            DialogResult = true;
            this.Close();
        }
    }
}
