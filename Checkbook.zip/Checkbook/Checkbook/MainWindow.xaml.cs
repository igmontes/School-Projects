﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Checkbook
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TransactionList transactionList = new TransactionList();
        CategoryList categoryList;

        public MainWindow()
        {
            InitializeComponent();
        }

        public TransactionList Transactions
        {
            get { return transactionList; }
            set { transactionList = value; }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //lbTransactions.ItemsSource = transactionList;
            lblBalance.Content = transactionList.Balance.ToString("C");
            categoryList = new CategoryList(transactionList);
            lbCategories.ItemsSource = categoryList;
        }

        private void lbTransactions_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbTransactions.SelectedIndex < 0) lbTransactions.SelectedIndex = 0;
            //int index = lbTransactions.SelectedIndex;  // this line is not really needed
            Transaction tr = transactionList[lbTransactions.SelectedIndex];
            tbId.Text = tr.Id.ToString();
            tbType.Text = tr.Type.ToString();
            tbDescription.Text = tr.Description;
            tbDate.Text = tr.Date.ToShortDateString();
            lblAmountString.Content = tr.AmountString;
            tbAmount.Text = tr.Amount.ToString("C");
            tbCategory.Text = tr.Category;
            tbCheckNum.Text = tr.Checknum;
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Transaction transaction;
            if (TryGetTransaction(Convert.ToInt32(tbId.Text), out transaction))
            {
                Edit editTransaction = new Edit(transaction, categoryList);
                if (editTransaction.ShowDialog() == true)
                {
                    this.DispayTransaction(transaction);
                    categoryList.Refresh();
                    lbCategories.ItemsSource = null;
                    lbCategories.ItemsSource = categoryList;
                }
            }
        }

        private void DispayTransaction(Transaction tr)
        {
            tbId.Text = tr.Id.ToString();
            tbType.Text = tr.Type.ToString();
            tbDescription.Text = tr.Description;
            tbDate.Text = tr.Date.ToShortDateString();
            lblAmountString.Content = tr.AmountString;
            tbAmount.Text = tr.Amount.ToString("C");
            tbCategory.Text = tr.Category;
            tbCheckNum.Text = tr.Checknum;
        }

        private bool TryGetTransaction(int id, out Transaction transaction)
        {
            transaction = null;
            foreach (Transaction tr in this.transactionList)
            {
                if (tr.Id == id)
                {
                    transaction = tr;
                }
            }

            return transaction != null;
        }

        private void UpdateTransaction(int id, Transaction transaction)
        {
            for (int i = 0; i < this.transactionList.Count; i++)
            {
                if (this.transactionList[i].Id == id)
                {
                    this.transactionList[i] = transaction;
                }
            }
        }

    }
}
