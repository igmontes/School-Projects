﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkbook
{
    public class CategoryList : List<Category>
    {
        TransactionList transactionList;

        public CategoryList(TransactionList transactionList)
        {
            this.transactionList = transactionList;
            Refresh();
        }

        public void AddTransaction(Transaction transaction)
        {
            foreach (Category category in this)
            {
                if (category.Title == transaction.Category)
                {
                    // Found it!
                    category.Amount += transaction.Amount;
                    return;
                }
            }
            Add(new Category(transaction.Category, transaction.Amount));
        }

        public void Refresh()
        {
            Clear();
            foreach (Transaction transaction in transactionList)
            {
                AddTransaction(transaction);
            }
            this.Sort();
        }
    }
}
