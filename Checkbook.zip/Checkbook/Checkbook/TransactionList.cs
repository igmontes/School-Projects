﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Checkbook
{
    public class TransactionList : ObservableCollection<Transaction>
    {
        // Use this to check if there is data in the db
        private bool DataInDatabase()
        {
            string connectionString = "Server=localhost;Database=Checkbook;Integrated Security=True";
            //string connectionString = "Data Source=.;Initial Catalog=Checkbook;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM CheckingTransaction", conn);

                try
                {
                    // Open the connection and start the reader
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Look for existing records
                    while (reader.Read())
                    {
                        // Populate data variables from the db
                        int dbId = (int)reader["TransactionId"];
                        DateTime dbDate = (DateTime)reader["TransactionDate"];
                        int dbType = (int)reader["TransactionType"];
                        String dbDescription = (String)reader["Description"];
                        String dbCategory = (String)reader["Category"];
                        Decimal dbAmount = (Decimal)reader["Amount"];
                        String dbCheckNum = (String)reader["CheckNum"];

                        Transaction dbTrans = null;
                        switch ((TransactionType)dbType)
                        {
                            case TransactionType.Check:
                                dbTrans = new Check(dbDate, dbDescription, dbCategory, dbAmount, dbCheckNum);
                                break;
                            case TransactionType.Debit:
                                dbTrans = new Debit(dbDate, dbDescription, dbCategory, dbAmount);
                                break;
                            case TransactionType.Deposit:
                                dbTrans = new Deposit(dbDate, dbDescription, dbCategory, dbAmount);
                                break;
                        }
                        Add(dbTrans);
                    }
                    reader.Close();
                }

                catch (SqlException e)
                {
                    Console.WriteLine("An exception occurred:" + e.Message);
                }
                return Count > 0;
            }
        }


        public TransactionList()
        {
            // Get out if we have database records
            if (DataInDatabase())
            {
                return;
            }

            string XMLFile = "<Transactions><Transaction><Id>1</Id><Date>11/23/2014</Date><Type>Deposit</Type><Description>Pay</Description><Category>Income</Category><Amount>1327</Amount></Transaction><Transaction><Id>2</Id><Date>11/24/2014</Date><Type>Check</Type><Description>Food</Description><Category>Food</Category><Amount>62</Amount><Checknum>2021</Checknum></Transaction><Transaction><Id>3</Id><Date>11/24/2014</Date><Type>Debit</Type><Description>ATM</Description><Category>Misc</Category><Amount>40</Amount></Transaction><Transaction><Id>4</Id><Date>11/25/2014</Date><Type>Check</Type><Description>Rent</Description><Category>Rent</Category><Amount>713</Amount><Checknum>2022</Checknum></Transaction><Transaction><Id>5</Id><Date>11/26/2014</Date><Type>Debit</Type><Description>Dinner</Description><Category>Friends</Category><Amount>37.29</Amount></Transaction><Transaction><Id>6</Id><Date>11/26/2014</Date><Type>Debit</Type><Description>Movie</Description><Category>Friends</Category><Amount>12.50</Amount></Transaction><Transaction><Id>7</Id><Date>11/27/2014</Date><Type>Deposit</Type><Description>Mom</Description><Category>Income</Category><Amount>100</Amount></Transaction><Transaction><Id>8</Id><Date>11/28/2014</Date><Type>Check</Type><Description>Costco</Description><Category>Misc</Category><Amount>15.72</Amount><Checknum>2024</Checknum></Transaction><Transaction><Id>9</Id><Date>11/29/2014</Date><Type>Debit</Type><Description>Gas</Description><Category>Gas</Category><Amount>43.83</Amount></Transaction><Transaction><Id>10</Id><Date>11/30/2014</Date><Type>Debit</Type><Description>Market</Description><Category>Food</Category><Amount>35.11</Amount></Transaction></Transactions>";

            Regex XMLPattern = new Regex(@"^(\<Transactions\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<Transaction\>)(.*)(\<\/Transaction\>)(\<\/Transactions\>)$");
            Match XMLMatch = XMLPattern.Match(XMLFile);

            int i = 0;
            int x = 0;
            while (i < 30)
            {
                i += 3;
                x = i;
                Regex TransPattern = new Regex(@"^(\<Id\>)(.*)(\<\/Id\>)(\<Date\>)(.*)(\<\/Date\>)(\<Type\>)(.*)(\<\/Type\>)(\<Description\>)(.*)(\<\/Description\>)(\<Category\>)(.*)(\<\/Category\>)(\<Amount\>)(.*)(\<\/Amount\>)(\<Checknum\>)?(\d*)?(\<\/Checknum\>)?");

                Match IdMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                Match DateMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                Match TypeMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                Match DescriptionMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                Match CategoryMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                Match AmountMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());
                Match ChecknumMatch = TransPattern.Match(XMLMatch.Groups[i].ToString());

                // Cast amount to decimal
                decimal amount = decimal.Parse(AmountMatch.Groups[17].ToString());

                // Determine what type to use to populate the listbox
                Transaction trans = null;
                switch (TypeMatch.Groups[8].ToString())
                {
                    case "Check":
                        trans = new Check(DateTime.Parse(DateMatch.Groups[5].ToString()), DescriptionMatch.Groups[11].ToString(), 
                            CategoryMatch.Groups[14].ToString(), Decimal.Parse(AmountMatch.Groups[17].ToString()), 
                            ChecknumMatch.Groups[20].ToString());
                        break;
                    case "Debit":
                        trans = new Debit(DateTime.Parse(DateMatch.Groups[5].ToString()), DescriptionMatch.Groups[11].ToString(), 
                            CategoryMatch.Groups[14].ToString(), Decimal.Parse(AmountMatch.Groups[17].ToString()));
                        break;
                    case "Deposit":
                        trans = new Deposit(DateTime.Parse(DateMatch.Groups[5].ToString()), DescriptionMatch.Groups[11].ToString(), 
                            CategoryMatch.Groups[14].ToString(), Decimal.Parse(AmountMatch.Groups[17].ToString()));
                        break;
                }

                // Create the transaction
                Add(trans);
            }

            string connectionString = "Server=localhost;Database=Checkbook;Integrated Security=True";
            //string connectionString = "Data Source=.;Initial Catalog=Checkbook;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // easier to wite to the db after the transaction list has been created
                    foreach (Transaction a in this)
                    {
                        SqlCommand cmd = new SqlCommand("INSERT INTO CheckingTransaction " + "(TransactionId, TransactionType, Category, TransactionDate, Description, Amount, Checknum) values (" + a.Id + "," + a.Type + ", '" + a.Category + "', '" + a.Date.ToShortDateString() + "','" + a.Description + "'," + a.Amount + ",'" + a.Checknum + "')", conn);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine("An exception occurred:" + e.Message);
                }
            }
        }


        public decimal Balance
        {
            get
            {
                decimal bal = 0;
                foreach (Transaction t in this)
                {
                    bal += t.CalculationAmount;
                }
                return bal;
            }
        }
    }
}
