﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkbook
{
    public class Category : IComparable<Category>
    {
        private String title;
        private Decimal amount;

        public Decimal Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        public String Title
        {
            get { return title; }
            set { title = value; }
        }

        public Category(String title, Decimal amount)
        {
            Title = title;
            Amount = amount;
        }

        public override string ToString()
        {
            return Title + "\t" + Amount.ToString("C");
        }

        public int CompareTo(Category other)
        {
            return Title.CompareTo(other.Title);
        }
    }
}
